function loadDiagram(name){

}